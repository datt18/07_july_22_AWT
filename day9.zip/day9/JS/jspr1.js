function c1(){
    document.getElementById("h1").scr="../HTML/image/download (2).jpg";
}
function c2(){
    document.getElementById("v2").scr="../HTML/image/download (2).jpg";
}
function c3(){
    document.getElementById("v3").scr="../HTML/image/download (2).jpg";
}
